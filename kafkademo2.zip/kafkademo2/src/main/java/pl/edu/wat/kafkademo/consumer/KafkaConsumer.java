package pl.edu.wat.kafkademo.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import pl.edu.wat.kafkademo.DemoModel;

@Component
public class KafkaConsumer {

    @KafkaListener(topics = "nazwa_topic", groupId = "test")
    public void listen(DemoModel demoModel) {
        System.out.println("Received message: " + demoModel.toString());
    }
}
