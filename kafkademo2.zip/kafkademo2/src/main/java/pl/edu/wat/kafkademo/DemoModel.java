package pl.edu.wat.kafkademo;

import lombok.Data;

@Data
public class DemoModel {
    private int id;
    private String name;
    private double amount;
}
