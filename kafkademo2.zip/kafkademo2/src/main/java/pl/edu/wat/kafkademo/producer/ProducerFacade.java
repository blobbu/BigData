package pl.edu.wat.kafkademo.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFutureCallback;
import pl.edu.wat.kafkademo.DemoModel;

@Component
public class ProducerFacade {

    private final KafkaTemplate<String, DemoModel> kafkaTemplate;
    private String topic = "nazwa_topic";

    @Autowired
    public ProducerFacade(KafkaTemplate<String, DemoModel> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessage(DemoModel demoModel) {
        kafkaTemplate.send(topic, demoModel);
    }

    public void sendMessageAsync(DemoModel demoModel) {
        var future = kafkaTemplate.send(topic, demoModel);

        future.addCallback(new ListenableFutureCallback<>() {
            @Override
            public void onFailure(Throwable throwable) {
                System.out.println(throwable.getMessage());
            }

            @Override
            public void onSuccess(SendResult<String, DemoModel> stringDemoModelSendResult) {
                System.out.println("Message: " + stringDemoModelSendResult.getProducerRecord().value().toString());
            }
        });
    }
}
