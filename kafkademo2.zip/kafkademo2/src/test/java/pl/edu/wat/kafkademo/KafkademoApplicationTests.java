package pl.edu.wat.kafkademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkademoApplicationTests {

    @Test
    void contextLoads() {
    }

}
